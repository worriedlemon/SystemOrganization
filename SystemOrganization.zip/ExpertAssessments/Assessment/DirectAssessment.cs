﻿namespace ExpertAssessments.Assessment
{
    public class DirectAssessment : AbstractAssessmentMethod
    {
        public DirectAssessment() : base("Direct")
        {

        }

        public override void Calculate()
        {
            // TODO Метод непосредственной оценки
        }
    }
}
